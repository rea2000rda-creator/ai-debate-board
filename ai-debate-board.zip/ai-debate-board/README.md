# เวทีถกเถียง — AI หลายแพลตฟอร์มร่วมหาคำตอบที่ดีที่สุด

เว็บแอปที่ให้ AI จากหลายค่าย (OpenAI, Google Gemini, Anthropic Claude) ตอบคำถามเดียวกัน
วิจารณ์คำตอบของกันและกันหลายรอบ แล้วโหวตหาคำตอบที่ดีที่สุด — ใช้ได้ทั้งผ่านหน้าเว็บ (กระดานสด)
และผ่าน **JSON API** ให้โปรแกรมหรือ AI ตัวอื่นเรียกใช้งานได้โดยตรง

## วิธีติดตั้งและรันบนเครื่อง

ต้องมี [Node.js](https://nodejs.org) เวอร์ชัน 18 ขึ้นไป

```bash
cd ai-debate-board
npm install
cp .env.example .env
```

เปิดไฟล์ `.env` ใส่ API key ของแพลตฟอร์มที่มี (อย่างน้อย 2 ตัว) และตั้ง `API_ACCESS_KEY`
เป็นรหัสลับของคุณเอง (ตั้งค่าอะไรก็ได้ ใช้กันไม่ให้คนอื่นยิง API มาใช้โควต้าคุณฟรีๆ)

```bash
npm start
```

เปิดเบราว์เซอร์ที่ `http://localhost:3000` เพื่อใช้กระดานแบบเห็นภาพ

## ทำให้เป็นเว็บไซต์จริงที่มีลิงก์ (สำหรับให้ AI/โปรแกรมอื่นเรียกใช้)

โค้ดนี้ต้องรันเป็นเซิร์ฟเวอร์ (มี backend เก็บ API key ลับ) จะ publish เป็นหน้าเว็บแบบ static ไม่ได้
วิธีที่ง่ายที่สุดคือขึ้นบนโฮสต์ที่รัน Node.js ได้ฟรี เช่น **Render.com**:

1. อัปโหลดโฟลเดอร์นี้ขึ้น GitHub repo
2. render.com → New → Web Service → เลือก repo
3. Build command: `npm install` / Start command: `npm start`
4. แท็บ Environment → ใส่ `OPENAI_API_KEY`, `GEMINI_API_KEY`, `ANTHROPIC_API_KEY`, `API_ACCESS_KEY`
5. Deploy → ได้ลิงก์ เช่น `https://your-app.onrender.com`

เมื่อได้ลิงก์แล้ว แชร์ endpoint `https://your-app.onrender.com/api/v1/debate` พร้อม `API_ACCESS_KEY`
ให้ AI/โปรแกรมอื่นเรียกใช้ได้เลย (ดูรายละเอียดด้านล่าง)

## JSON API — ให้ AI/โปรแกรมอื่นเรียกใช้โดยตรง

**เอกสาร API สด**: เปิด `GET /api/v1/docs` บนเว็บที่ deploy แล้ว จะได้ spec กลับมาเป็น JSON

**เรียกใช้งาน:**

```
POST /api/v1/debate
Content-Type: application/json
Authorization: Bearer <API_ACCESS_KEY>   (ถ้าตั้งค่าไว้)

{
  "question": "แนวทางไหนดีกว่ากันระหว่าง A กับ B",
  "rounds": 2
}
```

**ตัวอย่างด้วย curl:**

```bash
curl -X POST https://your-app.onrender.com/api/v1/debate \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_ACCESS_KEY" \
  -d '{"question":"เมืองหลวงของฝรั่งเศสคืออะไร","rounds":2}'
```

**รูปแบบผลลัพธ์ที่ได้กลับ (JSON):**

```json
{
  "question": "...",
  "rounds": 2,
  "providers": [{ "id": "openai", "label": "ChatGPT" }, ...],
  "transcript": { "openai": [{ "round": 1, "text": "..." }, ...], ... },
  "finalAnswers": [{ "id": "openai", "label": "ChatGPT", "text": "..." }, ...],
  "votes": [{ "voter": "gemini", "votedFor": "anthropic", "reason": "..." }, ...],
  "tally": { "openai": 0, "gemini": 1, "anthropic": 1 },
  "winner": "Claude",
  "winnerId": "anthropic"
}
```

หมายเหตุ: เรียกครั้งเดียว รอจนถกจบทุกรอบแล้วได้ผลลัพธ์ก้อนเดียวกลับมา (ไม่ใช่ streaming)
เหมาะสำหรับโปรแกรม/agent ที่ต้องการผลลัพธ์สุดท้ายไปใช้ต่อ ถ้าต้องการดูแบบสดทีละข้อความ ให้ใช้หน้าเว็บ
(ซึ่งใช้ endpoint แยก `/api/debate` แบบ Server-Sent Events)

## โครงสร้างไฟล์

- `server.js` — Express server, มีทั้ง JSON API (`/api/v1/debate`) และ SSE สำหรับหน้าเว็บ (`/api/debate`)
- `debate.js` — ตรรกะหลักของการถกเถียงและโหวต ใช้ร่วมกันทั้งสอง endpoint
- `providers.js` — อะแดปเตอร์เรียก API ของแต่ละแพลตฟอร์ม
- `public/` — หน้าเว็บ (HTML/CSS/JS ล้วน ไม่ต้อง build)

## คู่มือฉบับไม่ต้องรู้โค้ดเลย (ทำตามทีละขั้น)

ดูคู่มือละเอียดแบบไม่ใช้ terminal/คำสั่งใดๆ ได้ในข้อความที่ Claude อธิบายไว้ในแชท
สรุปสั้นๆ คือ: (1) เอาไฟล์นี้ขึ้น GitHub ผ่านหน้าเว็บ (ลากไฟล์วาง ไม่ต้องพิมพ์คำสั่ง)
(2) สมัคร render.com เชื่อมกับ GitHub repo (3) ใส่ API key ในช่อง Environment Variables บนเว็บ render
(4) กด Deploy จะได้ลิงก์เว็บมาใช้ทันที

## เพิ่มแพลตฟอร์ม AI อื่น

เปิด `providers.js` เพิ่มฟังก์ชัน `callXxx(messages)` ที่รับ array ข้อความแบบ
`[{role: 'system'|'user'|'assistant', content: string}]` แล้ว return string คำตอบ
จากนั้นเพิ่มรายการใน `REGISTRY` พร้อม `id`, `label`, `color`, `envKey`

## ข้อควรรู้

- ตั้ง `API_ACCESS_KEY` ก่อนเปิดเป็นเว็บสาธารณะเสมอ ไม่งั้นใครก็เรียก API ไปกินโควต้าเงินคุณได้
- ค่าใช้จ่าย API ของแต่ละแพลตฟอร์มคิดตามการใช้งานจริง ตรวจสอบราคาก่อนใช้เยอะๆ
- ห้าม commit ไฟล์ `.env` ขึ้น git (มี `.gitignore` กันไว้แล้ว)
- ยังไม่มีระบบล็อกอินผู้ใช้หลายคนหรือ rate limit ละเอียด ถ้าจะเปิดสาธารณะจริงจัง ควรเพิ่มการจำกัดจำนวนครั้ง/วันด้วย
